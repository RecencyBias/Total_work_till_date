# twitterscraper changelog

## 0.x.x

TBD

## 0.3.0 ( 2017-08-01 )
### Added
- Tweet class now also includes 'replies', 'retweets' and 'likes'

## 0.2.7 ( 2017-01-10 )
-----------

### Improved

- PR #26: use ``requests`` library for HTTP requests. Makes the use of urllib2 / urllib redundant. 

### Added: 
- changelog.txt for GitHub
- HISTORY.rst for PyPi
- README.rst for PyPi

## 0.2.6 ( 2017-01-02 )
-----------

### Improved 

- PR #25: convert date retrieved from timestamp to day precision
